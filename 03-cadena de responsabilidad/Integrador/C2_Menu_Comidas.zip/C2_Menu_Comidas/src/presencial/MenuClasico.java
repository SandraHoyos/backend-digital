package presencial;

public class MenuClasico extends Menu {

    public MenuClasico(Double precioBase) {
        super(precioBase);
    }
}
